<?php
// Configuración de la base de datos (WAMP por defecto)
return [
    'host'    => 'localhost',
    'name'    => 'adivina_quien',
    'user'    => 'root',
    'pass'    => '',
    'charset' => 'utf8mb4',
];
